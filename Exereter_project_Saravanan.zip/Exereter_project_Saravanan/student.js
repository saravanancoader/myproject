const student=[{
    "Student name": "Saravanan",
    "Student id": 1,
    "English": 100,
    "Tamil": 98,
    "Maths": 100,
    "Computer science": 35
}, {
    "Student name": "Rice Benedit",
    "Student id": 2,
    "English": 100,
    "Tamil": 98,
    "Maths": 100,
    "Computer science": 35
  }, {
    "Student name": "Geneva Randleson",
    "Student id": 3,
    "English": 100,
    "Tamil": 98,
    "Maths": 100,
    "Computer science": 35
  }, {
    "Student name": "Liv Chant",
    "Student id": 4,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }, {
    "Student name": "Lorin Bertouloume",
    "Student id": 5,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }, {
    "Student name": "Westbrooke Willetts",
    "Student id": 6,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }, {
    "Student name": "Brina Middleton",
    "Student id": 7,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }, {
    "Student name": "Valeda Berney",
    "Student id": 8,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }, {
    "Student name": "Flynn Rymer",
    "Student id": 9,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }, {
    "Student name": "Maudie Inns",
    "Student id": 10,
    "English": "100",
    "Tamil": "98",
    "Maths": "100",
    "Computer science": "35"
  }]
module.exports=student