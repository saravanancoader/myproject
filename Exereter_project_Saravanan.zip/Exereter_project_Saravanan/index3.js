console.log('index3.js');
const express=require('express');
const student = require('./student');
//const student = require('./student');

const app=express()
app.use(express.json())


const students=require('./student')
app.listen(1000 , ()=>{

    console.log('lisitening the server 1000');
})






app.get('/api/read',(req,res)=>{


    res.json(students)
    
    })

    app.post('/api/add',(req,res)=>{

            
                console.log("post request sended");

                        if(!req.body.Studentname){
                   res.status(400)
                 return res.json({error: "name is required...."})
                              
                }
                 const user={

                    Studentname: req.body.Studentname,
                    Studentid: students.length+1,
                    English: req.body.English,
                    Tamil: req.body.Tamil,
                    Maths: req.body.Maths,
                    Computerscience: req.body.Computerscience



                 }
                 students.push(user)

        res.json(students)
        res.status(200);
    
        console.log(students)



        })
    
    app.put('/api/update/:id',(req,res)=>{

            let Studentid = req.params.id
            let Studentname=req.body.Studentname
              let English= req.body.English
                    let Tamil= req.body.Tamil
                    let  Maths= req.body.Maths
                    let Computerscience= req.body.Computerscience

 let index=students.findIndex((student)=>{

return (student.Studentid==Number.parseInt(Studentid))




 })
 if(index >=0){
let std=students[index]
std.Studentname=Studentname
std.English=English
std.Tamil=Tamil
std.Maths=Maths
std.Computerscience=Computerscience
res.json(std)
 }else{

res.status(404)



 }

 

    })


    app.delete("/api/delete/:id",(req,res)=>{

let id=req.params.id;
let index=students.findIndex((student)=>{


return (student.id==Number.parseInt(id))

})
if(index>=0){

    let std=students[index]
    students.splice(index,1)
    res.json(std)

}else{
res.status(404)

}


})


